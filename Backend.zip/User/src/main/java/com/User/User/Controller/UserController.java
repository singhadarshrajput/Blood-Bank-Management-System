package com.User.User.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.User.User.Dao.UserDAO;
import com.User.User.Model.User;



@RestController
@RequestMapping("/")
public class UserController {

	@Autowired
	UserDAO userDAO;

	/* to save a blood bank */
	@PostMapping("/user")
	public User createUser(@Valid @RequestBody User user) {
		
		return userDAO.save(user);
	}

	/* get all blood users */
	@GetMapping("/user")
	public List<User> getAllUser() {
		System.out.println("getAll");
		return userDAO.findAll();
	}
	
	/* Delete a product */
	@DeleteMapping("/user/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable(value = "id") Long dId) {

		Optional<User> user = userDAO.findOne(dId);
		if (user == null) {
			return ResponseEntity.notFound().build();
		}
		userDAO.delete(user.get());

		return ResponseEntity.ok().build();

	}
	
	@PostMapping("/user/login")
	public User login(@Valid @RequestBody User user) {
		return userDAO.login(user);
	}
	
	@PutMapping("/user/")
	public ResponseEntity<User> updateUser(@Valid @RequestBody User user) {

		User userOld = userDAO.findOneByEmail(user.getEmail());
		if (userOld == null) {
			return ResponseEntity.notFound().build();
		}
		user.setUser_id(userOld.getUser_id());
		user.setPassword(userOld.getPassword());;
		userDAO.save(user);
		 return ResponseEntity.ok().build();

	}
}


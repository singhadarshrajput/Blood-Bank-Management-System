package com.User.User.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.User.User.Model.User;


public interface UserRepository extends JpaRepository<User, Long>{

	@Query(value = "SELECT * FROM user WHERE email = :email and password= :password", nativeQuery = true)
	User userLogin(String email,String password);
	
	@Query(value = "SELECT * FROM user WHERE location = :location", nativeQuery = true)
	List<User> getUserByLocation(String location);
	
	@Query(value = "SELECT *  FROM user WHERE email = :email", nativeQuery = true)
	User findOneByEmail(String email);
	
}

package com.User.User.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.User.User.Model.User;
import com.User.User.Repository.UserRepository;


@Service
public class UserDAO {

	@Autowired
	UserRepository userRepository;
	public User save(User user) {
		return userRepository.save(user);
	}
	
	public void delete(User user) {
		userRepository.delete(user);
	}
	
	public User findOneByEmail(String email) {
		// return null;
		return userRepository.findOneByEmail(email);
	}
	public List<User> findAll(){
		return userRepository.findAll();
	}
	
	public Optional<User> findOne(Long did) {
		// return null;
		return userRepository.findById(did);
	}
	public  User login(User user) {
		return userRepository.userLogin(user.getEmail(),user.getPassword());
	}
	
	public List<User>  getUserByLocation(String location){
		return userRepository.getUserByLocation(location);
	}
}

package com.BloodDetails.BloodDetails.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BloodDetails.BloodDetails.Model.BloodDetails;
import com.BloodDetails.BloodDetails.Repository.BloodDetailsRepository;


@Service
public class BloodDetailsDAO {

	@Autowired
	BloodDetailsRepository bloodDetailsRepository;
	public BloodDetails save(BloodDetails bd) {
		return bloodDetailsRepository.save(bd);
	}
	
	public void delete(BloodDetails bd) {
		bloodDetailsRepository.delete(bd);
	}
	
	public List<BloodDetails> findAll(){
		return bloodDetailsRepository.findAll();
	}
	
	public Optional<BloodDetails> findOne(Long bdid) {
		// return null;
		return bloodDetailsRepository.findById(bdid);
	}
	public List<BloodDetails>  getBloodBankByLocation(String location){
		return bloodDetailsRepository.getBloodBankByLocation(location);
	}
}

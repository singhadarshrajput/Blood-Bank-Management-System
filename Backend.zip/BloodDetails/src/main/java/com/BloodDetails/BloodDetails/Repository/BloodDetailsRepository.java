package com.BloodDetails.BloodDetails.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.BloodDetails.BloodDetails.Model.BloodDetails;


public interface BloodDetailsRepository extends JpaRepository<BloodDetails, Long>{

	@Query(value = "SELECT * FROM blood_details WHERE location = :location", nativeQuery = true)
	List<BloodDetails> getBloodBankByLocation(String location);

	BloodDetails save(BloodDetails bd);

	void delete(BloodDetails bd);

	List<BloodDetails> findAll();

	Optional<BloodDetails> findById(Long bdid);
}
